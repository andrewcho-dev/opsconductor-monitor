-- Exported mappings for cisco_asa
-- Generated at 2026-01-10T01:19:54.302487Z

-- Severity mappings
INSERT INTO severity_mappings (connector_type, source_value, source_field, target_severity, enabled, description) VALUES
('cisco_asa', 'cpu_critical', 'event_type', 'critical', true, 'CPU usage critical'),
('cisco_asa', 'cpu_high', 'event_type', 'warning', true, 'CPU usage high'),
('cisco_asa', 'device_offline', 'event_type', 'critical', false, 'Firewall offline'),
('cisco_asa', 'device_online', 'event_type', 'clear', true, 'Firewall online'),
('cisco_asa', 'failover', 'event_type', 'major', true, 'Cisco ASA failover event. Primary/secondary role change occurred. Check failed unit for hardware or connectivity issues.'),
('cisco_asa', 'failover_active', 'event_type', 'warning', true, 'Failover to standby'),
('cisco_asa', 'failover_failed', 'event_type', 'critical', false, 'Failover unit in failed state'),
('cisco_asa', 'failover_issue', 'event_type', 'warning', false, 'Failover state abnormal'),
('cisco_asa', 'high_cpu', 'event_type', 'warning', true, 'Cisco ASA CPU utilization high. Firewall processing load elevated. May indicate attack, misconfiguration, or capacity issue.'),
('cisco_asa', 'ike_tunnel_down', 'event_type', 'critical', true, 'IKE SA not established'),
('cisco_asa', 'interface_down', 'event_type', 'critical', true, 'Interface down'),
('cisco_asa', 'interface_up', 'event_type', 'clear', true, 'Interface up'),
('cisco_asa', 'ipsec_tunnel_down', 'event_type', 'critical', true, 'Cisco ASA IPsec VPN tunnel is down. Site-to-site or remote access VPN connection lost. Check peer connectivity, certificates, and IKE configuration.'),
('cisco_asa', 'memory_critical', 'event_type', 'critical', true, 'Memory usage critical'),
('cisco_asa', 'memory_high', 'event_type', 'warning', false, 'Memory usage high'),
('cisco_asa', 'threat_detected', 'event_type', 'major', true, 'Security threat detected'),
('cisco_asa', 'vpn_peer_down', 'event_type', 'critical', true, 'VPN peer is not responding'),
('cisco_asa', 'vpn_tunnel_down', 'event_type', 'critical', true, 'VPN tunnel down'),
('cisco_asa', 'vpn_tunnel_up', 'event_type', 'clear', true, 'VPN tunnel established')
ON CONFLICT (connector_type, source_value, source_field) DO UPDATE SET
    target_severity = EXCLUDED.target_severity,
    description = EXCLUDED.description;

-- Category mappings
INSERT INTO category_mappings (connector_type, source_value, source_field, target_category, enabled, description) VALUES
('cisco_asa', 'cpu_critical', 'event_type', 'compute', true, 'CPU usage critical'),
('cisco_asa', 'cpu_high', 'event_type', 'compute', true, 'CPU usage high'),
('cisco_asa', 'device_offline', 'event_type', 'security', false, 'Device events'),
('cisco_asa', 'failover_active', 'event_type', 'network', true, 'Failover events'),
('cisco_asa', 'failover_failed', 'event_type', 'network', false, 'Failover unit in failed state'),
('cisco_asa', 'failover_issue', 'event_type', 'network', false, 'Failover state abnormal'),
('cisco_asa', 'ike_tunnel_down', 'event_type', 'network', true, 'IKE SA not established'),
('cisco_asa', 'interface_down', 'event_type', 'network', true, 'Interface events'),
('cisco_asa', 'ipsec_tunnel_down', 'event_type', 'network', true, 'IPSec VPN tunnel is down'),
('cisco_asa', 'memory_critical', 'event_type', 'compute', true, 'Memory usage critical'),
('cisco_asa', 'memory_high', 'event_type', 'compute', true, 'Memory usage high'),
('cisco_asa', 'threat_detected', 'event_type', 'security', true, 'Security events'),
('cisco_asa', 'vpn_peer_down', 'event_type', 'network', false, 'VPN peer is not responding'),
('cisco_asa', 'vpn_tunnel_down', 'event_type', 'security', true, 'VPN events')
ON CONFLICT (connector_type, source_value, source_field) DO UPDATE SET
    target_category = EXCLUDED.target_category,
    description = EXCLUDED.description;
