-- Exported mappings for snmp_trap
-- Generated at 2026-01-10T01:19:54.341665Z

-- Severity mappings
INSERT INTO severity_mappings (connector_type, source_value, source_field, target_severity, enabled, description) VALUES
('snmp_trap', '1.3.6.1.4.1.31926.1.1.2.1.1', 'trap_oid', 'critical', true, 'Siklu RF Link Down (raise)'),
('snmp_trap', '1.3.6.1.4.1.31926.1.1.2.1.2', 'trap_oid', 'clear', true, 'Siklu RF Link Up (clear)'),
('snmp_trap', '1.3.6.1.4.1.31926.1.2.1.3.1', 'trap_oid', 'major', true, 'Siklu RSSI Low (raise)'),
('snmp_trap', '1.3.6.1.4.1.31926.1.2.1.3.2', 'trap_oid', 'clear', true, 'Siklu RSSI Normal (clear)'),
('snmp_trap', '1.3.6.1.4.1.31926.1.2.2.4.1', 'trap_oid', 'warning', true, 'Siklu Modulation Degraded (raise)'),
('snmp_trap', '1.3.6.1.4.1.31926.1.2.2.4.2', 'trap_oid', 'clear', true, 'Siklu Modulation Restored (clear)'),
('snmp_trap', '1.3.6.1.4.1.31926.1.3.1.1.1', 'trap_oid', 'major', true, 'Siklu Temperature High (raise)'),
('snmp_trap', '1.3.6.1.4.1.31926.1.3.1.1.2', 'trap_oid', 'clear', true, 'Siklu Temperature Normal (clear)'),
('snmp_trap', '1.3.6.1.4.1.31926.1.3.2.2.1', 'trap_oid', 'critical', true, 'Siklu Power Fault (raise)'),
('snmp_trap', '1.3.6.1.4.1.31926.1.3.2.2.2', 'trap_oid', 'clear', true, 'Siklu Power Normal (clear)'),
('snmp_trap', '1.3.6.1.4.1.31926.1.4.1.1.1', 'trap_oid', 'major', true, 'Siklu Sync Lost (raise)'),
('snmp_trap', '1.3.6.1.4.1.31926.1.4.1.1.2', 'trap_oid', 'clear', true, 'Siklu Sync Restored (clear)'),
('snmp_trap', '1.3.6.1.4.1.31926.1.5.1.0', 'trap_oid', 'warning', true, 'Siklu Device Reboot'),
('snmp_trap', '1.3.6.1.4.1.31926.1.5.2.0', 'trap_oid', 'info', true, 'Siklu Config Change'),
('snmp_trap', '1.3.6.1.4.1.31926.3.1', 'trap_oid', 'info', false, 'Siklu Status Notification'),
('snmp_trap', '1.3.6.1.6.3.1.1.5.3', 'trap_oid', 'warning', true, 'Standard Link Down'),
('snmp_trap', '1.3.6.1.6.3.1.1.5.4', 'trap_oid', 'clear', true, 'Standard Link Up'),
('snmp_trap', 'authenticationFailure', 'trap_type', 'warning', true, 'SNMP authentication failure'),
('snmp_trap', 'coldStart', 'trap_type', 'warning', true, 'Device cold start'),
('snmp_trap', 'linkDown', 'trap_type', 'critical', true, 'Interface link down'),
('snmp_trap', 'linkUp', 'trap_type', 'clear', true, 'Interface link up'),
('snmp_trap', 'siklu_rf_link_down', 'trap_type', 'critical', true, 'Siklu RF link down SNMP trap. Wireless radio link has failed. Immediate attention required to restore connectivity.'),
('snmp_trap', 'warmStart', 'trap_type', 'info', true, 'Device warm start')
ON CONFLICT (connector_type, source_value, source_field) DO UPDATE SET
    target_severity = EXCLUDED.target_severity,
    description = EXCLUDED.description;

-- Category mappings
INSERT INTO category_mappings (connector_type, source_value, source_field, target_category, enabled, description) VALUES
('snmp_trap', '1.3.6.1.4.1.31926.1.1.2.1.1', 'trap_oid', 'wireless', true, 'Siklu RF Link Down'),
('snmp_trap', '1.3.6.1.4.1.31926.1.1.2.1.2', 'trap_oid', 'wireless', true, 'Siklu RF Link Up'),
('snmp_trap', '1.3.6.1.4.1.31926.1.2.1.3.1', 'trap_oid', 'wireless', true, 'Siklu RSSI Low'),
('snmp_trap', '1.3.6.1.4.1.31926.1.2.1.3.2', 'trap_oid', 'wireless', true, 'Siklu RSSI Normal'),
('snmp_trap', '1.3.6.1.4.1.31926.1.2.2.4.1', 'trap_oid', 'wireless', true, 'Siklu Modulation Degraded'),
('snmp_trap', '1.3.6.1.4.1.31926.1.2.2.4.2', 'trap_oid', 'wireless', true, 'Siklu Modulation Restored'),
('snmp_trap', '1.3.6.1.4.1.31926.1.3.1.1.1', 'trap_oid', 'environment', true, 'Siklu Temperature High'),
('snmp_trap', '1.3.6.1.4.1.31926.1.3.1.1.2', 'trap_oid', 'environment', true, 'Siklu Temperature Normal'),
('snmp_trap', '1.3.6.1.4.1.31926.1.3.2.2.1', 'trap_oid', 'power', true, 'Siklu Power Fault'),
('snmp_trap', '1.3.6.1.4.1.31926.1.3.2.2.2', 'trap_oid', 'power', true, 'Siklu Power Normal'),
('snmp_trap', '1.3.6.1.4.1.31926.1.4.1.1.1', 'trap_oid', 'network', true, 'Siklu Sync Lost'),
('snmp_trap', '1.3.6.1.4.1.31926.1.4.1.1.2', 'trap_oid', 'network', true, 'Siklu Sync Restored'),
('snmp_trap', '1.3.6.1.4.1.31926.1.5.1.0', 'trap_oid', 'wireless', true, 'Siklu Device Reboot'),
('snmp_trap', '1.3.6.1.4.1.31926.1.5.2.0', 'trap_oid', 'wireless', true, 'Siklu Config Change'),
('snmp_trap', '1.3.6.1.4.1.31926.3.1', 'trap_oid', 'wireless', true, 'Siklu Status Notification'),
('snmp_trap', '1.3.6.1.6.3.1.1.5.3', 'trap_oid', 'network', true, 'Standard Link Down'),
('snmp_trap', '1.3.6.1.6.3.1.1.5.4', 'trap_oid', 'network', true, 'Standard Link Up'),
('snmp_trap', 'authenticationFailure', 'trap_type', 'security', true, 'Security events'),
('snmp_trap', 'coldStart', 'trap_type', 'network', true, 'Device events'),
('snmp_trap', 'linkDown', 'trap_type', 'network', true, 'Interface events'),
('snmp_trap', 'linkUp', 'trap_type', 'network', true, 'Interface events'),
('snmp_trap', 'warmStart', 'trap_type', 'network', true, 'Device events')
ON CONFLICT (connector_type, source_value, source_field) DO UPDATE SET
    target_category = EXCLUDED.target_category,
    description = EXCLUDED.description;
