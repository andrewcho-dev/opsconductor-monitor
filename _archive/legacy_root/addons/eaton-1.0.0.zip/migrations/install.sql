-- Exported mappings for eaton
-- Generated at 2026-01-10T01:19:54.309502Z

-- Severity mappings
INSERT INTO severity_mappings (connector_type, source_value, source_field, target_severity, enabled, description) VALUES
('eaton', '1101', 'alarm_code', 'warning', true, 'UPS on battery power. Utility power has failed. UPS is supplying load from battery. Check utility power source and prepare for potential shutdown if extended outage.'),
('eaton', '1102', 'alarm_code', 'critical', true, 'UPS battery low. Battery capacity critically low during outage. Imminent shutdown. Initiate graceful shutdown of connected equipment immediately.'),
('eaton', '1103', 'alarm_code', 'major', true, 'UPS overload. Load exceeds UPS capacity. Risk of shutdown or damage. Reduce load immediately by disconnecting non-critical equipment.'),
('eaton', '1104', 'alarm_code', 'critical', true, 'UPS on bypass. UPS has switched to bypass mode. Load is unprotected from power anomalies. Investigate UPS fault condition.'),
('eaton', '1105', 'alarm_code', 'major', true, 'UPS fault. Internal UPS fault detected. May affect protection capability. Contact Eaton support for diagnostics.'),
('eaton', '1106', 'alarm_code', 'warning', true, 'UPS battery needs replacement. Battery end-of-life detected. Schedule battery replacement to maintain backup capability.'),
('eaton', '1107', 'alarm_code', 'info', true, 'UPS self-test in progress. Automatic or manual self-test running. Normal operation.'),
('eaton', '1108', 'alarm_code', 'warning', true, 'UPS temperature high. Operating temperature exceeds threshold. Check cooling and ventilation around UPS.'),
('eaton', '1109', 'alarm_code', 'major', true, 'UPS output voltage out of range. Output voltage deviation detected. May affect connected equipment. Check UPS configuration and load.'),
('eaton', 'battery_fault', 'alarm_type', 'critical', true, 'Battery fault detected'),
('eaton', 'bypass_active', 'alarm_type', 'warning', true, 'UPS on bypass'),
('eaton', 'device_offline', 'alarm_type', 'critical', true, 'UPS offline'),
('eaton', 'device_online', 'alarm_type', 'clear', true, 'UPS online'),
('eaton', 'high_temperature', 'alarm_type', 'warning', true, 'UPS temperature high'),
('eaton', 'low_battery', 'alarm_type', 'critical', true, 'Battery low'),
('eaton', 'normal', 'alarm_type', 'clear', true, 'UPS status normal'),
('eaton', 'on_battery', 'alarm_type', 'critical', true, 'UPS on battery'),
('eaton', 'overload', 'alarm_type', 'critical', true, 'UPS overload'),
('eaton', 'utility_restored', 'alarm_type', 'clear', true, 'Utility power restored')
ON CONFLICT (connector_type, source_value, source_field) DO UPDATE SET
    target_severity = EXCLUDED.target_severity,
    description = EXCLUDED.description;

-- Category mappings
INSERT INTO category_mappings (connector_type, source_value, source_field, target_category, enabled, description) VALUES
('eaton', 'bypass_active', 'alarm_type', 'power', true, 'Bypass events'),
('eaton', 'device_offline', 'alarm_type', 'power', true, 'Device events'),
('eaton', 'high_temperature', 'alarm_type', 'environment', true, 'Environment events'),
('eaton', 'low_battery', 'alarm_type', 'power', true, 'Battery events'),
('eaton', 'on_battery', 'alarm_type', 'power', true, 'Power events'),
('eaton', 'overload', 'alarm_type', 'power', true, 'Load events')
ON CONFLICT (connector_type, source_value, source_field) DO UPDATE SET
    target_category = EXCLUDED.target_category,
    description = EXCLUDED.description;
