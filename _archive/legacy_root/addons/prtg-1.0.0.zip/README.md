# PRTG Network Monitor

Connect to PRTG Network Monitor for centralized alerting

## Installation

Upload this zip file via the OpsConductor Addons page at `/connectors/addons`.

## Configuration

Configure this addon in the Connectors settings after installation.

## Version

- Version: 1.0.0
- Author: OpsConductor
- Category: nms
- Capabilities: polling, webhooks
