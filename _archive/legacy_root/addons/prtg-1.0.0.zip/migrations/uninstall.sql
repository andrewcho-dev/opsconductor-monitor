-- Uninstall migration for prtg addon
-- This file is executed when the addon is uninstalled

-- Remove all severity mappings for this connector
DELETE FROM severity_mappings WHERE connector_type = 'prtg';

-- Remove all category mappings for this connector
DELETE FROM category_mappings WHERE connector_type = 'prtg';

-- Add any additional cleanup here (addon-specific tables, etc.)
