-- Exported mappings for prtg
-- Generated at 2026-01-10T01:19:54.334429Z

-- Severity mappings
INSERT INTO severity_mappings (connector_type, source_value, source_field, target_severity, enabled, description) VALUES
('prtg', '1', 'status', 'warning', true, 'PRTG status code 1 - Unknown state. Sensor has not yet collected data or is in an undefined state. Wait for next scan cycle.'),
('prtg', '10', 'status', 'warning', true, 'PRTG status code 10 - Unusual value detected. Reading is outside historical norms but not necessarily bad. Review for anomalies.'),
('prtg', '11', 'status', 'warning', true, 'PRTG status code 11 - Sensor type not licensed. PRTG license does not include this sensor type. Upgrade license or remove sensor.'),
('prtg', '12', 'status', 'info', true, 'PRTG status code 12 - Paused until specified date/time. Sensor will auto-resume at scheduled time.'),
('prtg', '13', 'status', 'major', true, 'PRTG status code 13 - Device or sensor is down. Target not responding or service failed. Check connectivity and service status.'),
('prtg', '14', 'status', 'major', true, 'PRTG status code 14 - Partial failure. Some channels failed while others succeeded. Review individual channel status.'),
('prtg', '2', 'status', 'info', true, 'PRTG status code 2 - Sensor is scanning/collecting data. Normal operation, data will be available shortly.'),
('prtg', '3', 'status', 'clear', true, 'PRTG status code 3 - Sensor is healthy and operating normally. All monitored values within acceptable thresholds.'),
('prtg', '4', 'status', 'warning', true, 'PRTG status code 4 - Warning threshold exceeded. One or more monitored values outside normal range but not critical. Investigate soon.'),
('prtg', '5', 'status', 'critical', true, 'PRTG status code 5 - Critical threshold exceeded or sensor in error state. Immediate attention required. Service may be impacted.'),
('prtg', '6', 'status', 'major', true, 'PRTG status code 6 - No Probe available. The probe monitoring this sensor is offline or disconnected. Check probe server.'),
('prtg', '7', 'status', 'info', true, 'PRTG status code 7 - Sensor is paused by user. Monitoring temporarily suspended. Resume when ready.'),
('prtg', '8', 'status', 'info', true, 'PRTG status code 8 - Sensor paused by dependency. Parent device or sensor is down, so this sensor is auto-paused.'),
('prtg', '9', 'status', 'info', true, 'PRTG status code 9 - Sensor paused by schedule. Outside of monitoring window defined in schedule.'),
('prtg', 'camera', 'sensor_type', 'major', true, 'Camera status sensor alert. Monitored camera is reporting issues or is unreachable.'),
('prtg', 'disk_free', 'sensor_type', 'warning', true, 'Disk space sensor alert. Available disk space on monitored volume is below threshold. Free up disk space or expand storage.'),
('prtg', 'down', 'status_text', 'critical', true, 'PRTG "down" status text - Target device or service is not responding. Network issue, service crash, or device offline.'),
('prtg', 'paused', 'status_text', 'info', true, 'PRTG "paused" status text - Monitoring intentionally suspended. User action or schedule. No alerts generated while paused.'),
('prtg', 'ping', 'sensor_type', 'critical', true, 'ICMP Ping sensor failure. Target device is not responding to ping requests. Device may be offline, network path blocked, or ICMP filtered.'),
('prtg', 'probe_health', 'sensor_type', 'major', true, 'PRTG probe health issue. Remote probe experiencing problems. Check probe connectivity and system resources.'),
('prtg', 'snmp_disk_free', 'sensor_type', 'warning', true, 'SNMP disk space sensor alert. Disk space queried via SNMP is below configured threshold. Monitor disk usage trends.'),
('prtg', 'snmp_traffic', 'sensor_type', 'warning', true, 'SNMP traffic sensor alert. Network interface traffic or errors exceed threshold. Check for bandwidth saturation or interface errors.'),
('prtg', 'traffic', 'sensor_type', 'warning', true, 'Network traffic sensor alert. Interface bandwidth utilization or packet errors exceed threshold.'),
('prtg', 'tunnel', 'sensor_type', 'critical', true, 'VPN tunnel sensor failure. IPsec or VPN tunnel is down. Check tunnel endpoint connectivity and configuration.'),
('prtg', 'unknown', 'status_text', 'warning', true, 'PRTG "unknown" status text - Sensor state cannot be determined. May be initializing, probe issue, or configuration error.'),
('prtg', 'unusual', 'status_text', 'warning', true, 'PRTG "unusual" status text - Anomaly detected. Value significantly different from historical baseline. May indicate emerging issue.'),
('prtg', 'up', 'status_text', 'clear', true, 'PRTG "up" status text - Device/service is healthy and responding normally. All monitored values within acceptable range.'),
('prtg', 'uptime', 'sensor_type', 'info', true, 'System uptime sensor alert. Device uptime changed unexpectedly, indicating a reboot occurred.'),
('prtg', 'warning', 'status_text', 'warning', true, 'PRTG "warning" status text - Monitored value exceeded warning threshold. Not critical yet but trending toward problem.')
ON CONFLICT (connector_type, source_value, source_field) DO UPDATE SET
    target_severity = EXCLUDED.target_severity,
    description = EXCLUDED.description;

-- Category mappings
INSERT INTO category_mappings (connector_type, source_value, source_field, target_category, enabled, description) VALUES
('prtg', 'bandwidth', 'type', 'network', true, 'Bandwidth sensors'),
('prtg', 'cpu', 'type', 'compute', true, 'CPU sensors'),
('prtg', 'disk', 'type', 'storage', true, 'Disk sensors'),
('prtg', 'http', 'type', 'application', true, 'HTTP sensors'),
('prtg', 'humidity', 'type', 'environment', true, 'Humidity sensors'),
('prtg', 'memory', 'type', 'compute', true, 'Memory sensors'),
('prtg', 'ping', 'type', 'network', true, 'Ping sensors'),
('prtg', 'port', 'type', 'network', true, 'Port sensors'),
('prtg', 'snmp', 'type', 'network', true, 'SNMP sensors'),
('prtg', 'ssl', 'type', 'security', true, 'SSL sensors'),
('prtg', 'temperature', 'type', 'environment', true, 'Temperature sensors'),
('prtg', 'traffic', 'type', 'network', true, 'Traffic sensors'),
('prtg', 'ups', 'type', 'power', true, 'UPS sensors'),
('prtg', 'vmware', 'type', 'compute', true, 'VMware sensors'),
('prtg', 'wmi', 'type', 'compute', true, 'WMI sensors')
ON CONFLICT (connector_type, source_value, source_field) DO UPDATE SET
    target_category = EXCLUDED.target_category,
    description = EXCLUDED.description;
