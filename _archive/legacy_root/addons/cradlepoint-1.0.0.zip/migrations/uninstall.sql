-- Uninstall migration for cradlepoint addon
-- This file is executed when the addon is uninstalled

-- Remove all severity mappings for this connector
DELETE FROM severity_mappings WHERE connector_type = 'cradlepoint';

-- Remove all category mappings for this connector
DELETE FROM category_mappings WHERE connector_type = 'cradlepoint';

-- Add any additional cleanup here (addon-specific tables, etc.)
