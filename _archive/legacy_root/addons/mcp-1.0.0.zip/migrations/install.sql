-- Exported mappings for mcp
-- Generated at 2026-01-10T01:19:54.328393Z

-- Severity mappings
INSERT INTO severity_mappings (connector_type, source_value, source_field, target_severity, enabled, description) VALUES
('mcp', 'CLEAR', 'status', 'clear', true, 'Clear alarms'),
('mcp', 'CLEARED', 'status', 'clear', true, 'Cleared alarms'),
('mcp', 'CRITICAL', 'status', 'critical', true, 'Critical alarms'),
('mcp', 'INFO', 'status', 'info', true, 'Info alarms'),
('mcp', 'MAJOR', 'status', 'major', true, 'Major alarms'),
('mcp', 'MINOR', 'status', 'minor', true, 'Minor alarms'),
('mcp', 'WARNING', 'status', 'warning', true, 'Warning alarms')
ON CONFLICT (connector_type, source_value, source_field) DO UPDATE SET
    target_severity = EXCLUDED.target_severity,
    description = EXCLUDED.description;

-- Category mappings
INSERT INTO category_mappings (connector_type, source_value, source_field, target_category, enabled, description) VALUES
('mcp', 'communication', 'type', 'network', true, 'Communication alarms'),
('mcp', 'environment', 'type', 'environment', true, 'Environment alarms'),
('mcp', 'equipment', 'type', 'network', true, 'Equipment alarms'),
('mcp', 'power', 'type', 'power', true, 'Power alarms'),
('mcp', 'processing', 'type', 'compute', true, 'Processing alarms'),
('mcp', 'qos', 'type', 'network', true, 'QoS alarms'),
('mcp', 'security', 'type', 'security', true, 'Security alarms')
ON CONFLICT (connector_type, source_value, source_field) DO UPDATE SET
    target_category = EXCLUDED.target_category,
    description = EXCLUDED.description;
