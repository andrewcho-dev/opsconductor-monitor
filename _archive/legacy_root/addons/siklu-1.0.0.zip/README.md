# Siklu Radios

Monitor Siklu EtherHaul wireless radios

## Installation

Upload this zip file via the OpsConductor Addons page at `/connectors/addons`.

## Configuration

Configure this addon in the Connectors settings after installation.

## Version

- Version: 1.0.0
- Author: OpsConductor
- Category: device
- Capabilities: polling, snmp_traps
