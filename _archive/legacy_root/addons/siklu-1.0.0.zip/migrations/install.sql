-- Exported mappings for siklu
-- Generated at 2026-01-10T01:19:54.289037Z

-- Severity mappings
INSERT INTO severity_mappings (connector_type, source_value, source_field, target_severity, enabled, description) VALUES
('siklu', 'device_offline', 'alert_type', 'critical', true, 'Radio offline'),
('siklu', 'device_offline', 'event_type', 'critical', true, 'Siklu wireless radio offline. Point-to-point or point-to-multipoint radio not responding. Check power, alignment, and network connectivity.'),
('siklu', 'device_offline', 'status', 'critical', true, 'Radio offline/unreachable'),
('siklu', 'device_online', 'alert_type', 'clear', true, 'Radio online'),
('siklu', 'device_online', 'status', 'clear', false, 'Radio online (clear event)'),
('siklu', 'ethernet_down', 'alert_type', 'major', true, 'Ethernet port down'),
('siklu', 'ethernet_down', 'status', 'major', true, 'Ethernet port down'),
('siklu', 'ethernet_up', 'alert_type', 'clear', true, 'Ethernet port up'),
('siklu', 'ethernet_up', 'status', 'clear', false, 'Ethernet port up (clear event)'),
('siklu', 'high_temperature', 'alert_type', 'warning', true, 'Radio temperature high'),
('siklu', 'high_temperature', 'status', 'warning', true, 'High temperature'),
('siklu', 'link_down', 'alert_type', 'critical', true, 'Radio link down'),
('siklu', 'link_down', 'status', 'critical', true, 'Radio link down'),
('siklu', 'link_up', 'alert_type', 'clear', true, 'Radio link up'),
('siklu', 'link_up', 'status', 'clear', false, 'Radio link up (clear event)'),
('siklu', 'modulation_drop', 'status', 'warning', true, 'Modulation reduced'),
('siklu', 'rf_link_down', 'event_type', 'critical', true, 'Siklu RF link down. Wireless link between radios has failed. Check for interference, alignment issues, or hardware failure at either end.'),
('siklu', 'rsl_critical', 'alert_type', 'critical', true, 'RSL critically low'),
('siklu', 'rsl_critical', 'status', 'major', true, 'RSL below critical threshold'),
('siklu', 'rsl_low', 'alert_type', 'warning', true, 'RSL below threshold'),
('siklu', 'rsl_low', 'status', 'warning', true, 'RSL below warning threshold'),
('siklu', 'signal_low', 'event_type', 'warning', true, 'Siklu signal strength low. RF signal below optimal threshold. Link may be unstable. Check antenna alignment and for obstructions.'),
('siklu', 'throughput_degraded', 'event_type', 'warning', true, 'Siklu throughput degraded. Achieved throughput below expected capacity. May indicate interference or modulation downshift.')
ON CONFLICT (connector_type, source_value, source_field) DO UPDATE SET
    target_severity = EXCLUDED.target_severity,
    description = EXCLUDED.description;

-- Category mappings
INSERT INTO category_mappings (connector_type, source_value, source_field, target_category, enabled, description) VALUES
('siklu', 'device_offline', 'type', 'network', true, 'Radio offline'),
('siklu', 'device_offline', 'alert_type', 'wireless', true, 'Device events'),
('siklu', 'device_online', 'type', 'network', true, 'Radio online'),
('siklu', 'ethernet_down', 'alert_type', 'network', true, 'Network events'),
('siklu', 'ethernet_down', 'type', 'network', true, 'Ethernet port down'),
('siklu', 'ethernet_up', 'type', 'network', false, 'Ethernet port up'),
('siklu', 'high_temperature', 'type', 'environment', true, 'High temperature'),
('siklu', 'high_temperature', 'alert_type', 'environment', true, 'Environment events'),
('siklu', 'link_down', 'type', 'wireless', true, 'Radio link down'),
('siklu', 'link_down', 'alert_type', 'wireless', true, 'Wireless events'),
('siklu', 'link_up', 'type', 'wireless', false, 'Radio link up'),
('siklu', 'modulation_drop', 'type', 'wireless', true, 'Modulation reduced'),
('siklu', 'rsl_critical', 'type', 'wireless', true, 'RSL critical'),
('siklu', 'rsl_low', 'type', 'wireless', true, 'RSL warning'),
('siklu', 'rsl_low', 'alert_type', 'wireless', true, 'Signal events')
ON CONFLICT (connector_type, source_value, source_field) DO UPDATE SET
    target_category = EXCLUDED.target_category,
    description = EXCLUDED.description;
