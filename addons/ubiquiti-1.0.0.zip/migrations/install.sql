-- Exported mappings for ubiquiti
-- Generated at 2026-01-10T01:19:54.295820Z

-- Severity mappings
INSERT INTO severity_mappings (connector_type, source_value, source_field, target_severity, enabled, description) VALUES
('ubiquiti', 'device_offline', 'status', 'critical', true, 'Ubiquiti device is offline or unreachable. Check power, network connectivity, and device status in UISP.'),
('ubiquiti', 'device_offline', 'alert_type', 'critical', true, 'AP offline'),
('ubiquiti', 'device_online', 'alert_type', 'clear', true, 'AP online'),
('ubiquiti', 'device_online', 'status', 'clear', true, 'Device came back online - clears device_offline alert.'),
('ubiquiti', 'firmware_update', 'status', 'info', true, 'Firmware update available for this device. Consider scheduling maintenance window for update.'),
('ubiquiti', 'high_cpu', 'status', 'warning', false, 'CPU utilization exceeds configured threshold. May indicate heavy traffic, attack, or process issue.'),
('ubiquiti', 'high_cpu', 'alert_type', 'warning', true, 'CPU utilization high'),
('ubiquiti', 'high_memory', 'status', 'warning', false, 'Memory usage exceeds configured threshold. May require device restart or configuration review.'),
('ubiquiti', 'interface_down', 'alert_type', 'major', true, 'Interface down'),
('ubiquiti', 'interface_down', 'status', 'major', true, 'Network interface is down on the device. Check cable, port, or remote device.'),
('ubiquiti', 'interface_up', 'alert_type', 'clear', true, 'Interface up'),
('ubiquiti', 'interface_up', 'status', 'clear', true, 'Network interface came back up - clears interface_down alert.'),
('ubiquiti', 'outage', 'status', 'critical', true, 'Network outage detected for this device. Site may be down or experiencing connectivity issues.'),
('ubiquiti', 'outage_ended', 'alert_type', 'clear', true, 'Outage ended'),
('ubiquiti', 'outage_ended', 'status', 'clear', true, 'Network outage has ended - clears outage alert.'),
('ubiquiti', 'outage_started', 'alert_type', 'critical', true, 'Outage started'),
('ubiquiti', 'signal_degraded', 'status', 'warning', true, 'Wireless signal strength is below -70 dBm. Check antenna alignment, interference, or distance.'),
('ubiquiti', 'temperature_critical', 'status', 'critical', true, 'Device temperature is critically high. Immediate attention required to prevent damage.'),
('ubiquiti', 'temperature_high', 'status', 'warning', true, 'Device temperature is elevated. Check ventilation and ambient temperature.')
ON CONFLICT (connector_type, source_value, source_field) DO UPDATE SET
    target_severity = EXCLUDED.target_severity,
    description = EXCLUDED.description;

-- Category mappings
INSERT INTO category_mappings (connector_type, source_value, source_field, target_category, enabled, description) VALUES
('ubiquiti', 'device_offline', 'type', 'network', true, 'Device availability issue'),
('ubiquiti', 'device_offline', 'alert_type', 'wireless', true, 'AP events'),
('ubiquiti', 'device_online', 'type', 'network', true, 'Device availability restored'),
('ubiquiti', 'firmware_update', 'type', 'application', false, 'Firmware maintenance needed'),
('ubiquiti', 'high_cpu', 'alert_type', 'compute', true, 'Resource events'),
('ubiquiti', 'high_cpu', 'type', 'compute', false, 'Resource utilization issue'),
('ubiquiti', 'high_memory', 'type', 'compute', false, 'Resource utilization issue'),
('ubiquiti', 'interface_down', 'alert_type', 'network', true, 'Interface events'),
('ubiquiti', 'interface_down', 'type', 'network', true, 'Interface connectivity issue'),
('ubiquiti', 'interface_up', 'type', 'network', true, 'Interface restored'),
('ubiquiti', 'outage', 'type', 'network', true, 'Network connectivity outage'),
('ubiquiti', 'outage_ended', 'type', 'network', true, 'Outage resolved'),
('ubiquiti', 'outage_started', 'alert_type', 'network', true, 'Outage events'),
('ubiquiti', 'signal_degraded', 'type', 'wireless', true, 'Wireless signal quality issue'),
('ubiquiti', 'temperature_critical', 'type', 'environment', true, 'Environmental temperature critical'),
('ubiquiti', 'temperature_high', 'type', 'environment', true, 'Environmental temperature warning')
ON CONFLICT (connector_type, source_value, source_field) DO UPDATE SET
    target_category = EXCLUDED.target_category,
    description = EXCLUDED.description;
